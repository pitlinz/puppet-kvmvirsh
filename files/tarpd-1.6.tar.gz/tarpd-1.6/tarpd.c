/* 	$Id: tarpd.c,v 1.6 1999/09/17 12:09:40 tricky Exp $	 */

#ifndef lint
static char vcid[] = "$Id: tarpd.c,v 1.6 1999/09/17 12:09:40 tricky Exp $";
#endif /* lint */

#include <sys/types.h>
#include <sys/socket.h>
#include <net/if.h>
#include <net/ethernet.h>
#include <net/if_arp.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <linux/if_packet.h>
#include <netinet/if_ether.h>

typedef struct _RuleList {
  struct _RuleList *next;
  int negate;
  unsigned long mask;
  unsigned long addr;
} RuleList;

typedef struct _ether_arp_frame { 
  struct ether_header ether_hdr;
  struct ether_arp arp;
} ether_arp_frame;




int test(RuleList *list, unsigned long addr) 
{
  while(list != NULL) {
    if ( (list->mask & addr) == list->addr)
      return ( 1 ^ list->negate );
    list = list->next;
  }

  return 0;
}




void arp_recv(int sock, ether_arp_frame *frame) 
{
  recvfrom(sock, frame, sizeof(ether_arp_frame), 0, NULL, 0);
}

void arp_reply(int sock, ether_arp_frame *frame, struct sockaddr_ll *ifs) 
{
  struct ether_arp *arp = &frame->arp;
  unsigned char ip[4];

  memcpy(&frame->ether_hdr.ether_dhost, &arp->arp_sha, ETH_ALEN);
  memcpy(&frame->ether_hdr.ether_shost, ifs->sll_addr, ETH_ALEN);

  memcpy(&arp->arp_tha, &arp->arp_sha, ETH_ALEN);
  memcpy(&arp->arp_sha, ifs->sll_addr, ETH_ALEN);

  memcpy(ip, &arp->arp_spa, 4);
  memcpy(&arp->arp_spa, &arp->arp_tpa, 4);
  memcpy(&arp->arp_tpa, ip, 4);

  arp->arp_op = htons(ARPOP_REPLY);

  sendto(sock, frame, sizeof(ether_arp_frame), 0, 
	 (struct sockaddr *)ifs, sizeof(struct sockaddr_ll));
}




int arp(RuleList *list, char *ifname) 
{
  int sock;
  struct sockaddr_ll ifs;
  struct ifreq ifr;

  sock = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ARP));

  if(sock == -1) {
    fprintf(stderr, "Socket error %d.\n", errno);
    exit(1);
  }

  /* Get the hwaddr and ifindex of the interface */
  memset(ifr.ifr_name, 0, IFNAMSIZ);
  strncpy(ifr.ifr_name, ifname, IFNAMSIZ);
  if(ioctl(sock, SIOCGIFHWADDR, &ifr) < 0) {
    fprintf(stderr, "ioctl SIOCGIFHWADDR %d\n", errno);
    exit(1);
  }

  memset(ifs.sll_addr, 0, ETH_ALEN);
  memcpy(ifs.sll_addr, ifr.ifr_hwaddr.sa_data, ETH_ALEN);

  if(ioctl(sock, SIOCGIFINDEX, &ifr) < 0) {
    fprintf(stderr, "ioctl SIOCGIFINDEX %d\n", errno);
    exit(1);
  }

  ifs.sll_family = AF_PACKET;
  ifs.sll_protocol = htons(ETH_P_ARP);
  ifs.sll_ifindex = ifr.ifr_ifindex;
  ifs.sll_hatype = ARPHRD_ETHER;
  ifs.sll_pkttype = PACKET_BROADCAST;
  ifs.sll_halen = ETH_ALEN;

  if(bind(sock, (struct sockaddr *)&ifs, sizeof(struct sockaddr_ll)) < 0) {
    fprintf(stderr, "Bind %s: %d\n", ifname, errno);
    exit(1);
  }

  while (1) {
    ether_arp_frame frame;
    unsigned long src;
    unsigned long dst;
    struct in_addr sia;
    struct in_addr dia;

    do {
      /* I just want to sleep abit */
      usleep(300);
      arp_recv(sock, &frame);
    } while (frame.arp.arp_op != htons(ARPOP_REQUEST));
    
    src = *((long *)frame.arp.arp_spa);
    dst = *((long *)frame.arp.arp_tpa);
    
    dia.s_addr = dst;
    sia.s_addr = src;
    
    if( test( list, ntohl( *((long *)frame.arp.arp_tpa) )) != 0 ) {
      /*
      printf("Would     reply to %s faking ", inet_ntoa(sia));
      printf("%s\n", inet_ntoa(dia));
      */
      arp_reply(sock, &frame, &ifs);
    }
  }
}




int main(int argc, char *argv[]) {
  int i;
  RuleList *list = malloc(sizeof(RuleList));
  RuleList *tmp = list;

  if(list == NULL) {
    fprintf(stderr, "Memory!\n");
    return 2;
  }

  if(argc < 4 || argc % 2 != 0) {
    fprintf(stderr, 
	    "Syntax: %s <interface> <[!]<addr> <netmask>> [<[!]<addr> <netmask>>] ...\n",
	    argv[0]);
    return 1;
  }

  
  i = 2;
  tmp->next = NULL;
  while ( i < argc ) {
    tmp->next = malloc(sizeof(RuleList));
    if(tmp->next == NULL) {
      fprintf(stderr, "Memory!\n");
      return 2;
    }
    
    tmp = tmp->next;

    if (*argv[i] == '!')
      tmp->negate = 1;
    else 
      tmp->negate = 0;

    tmp->addr = inet_network(argv[i++] + tmp->negate);
    tmp->mask = inet_network(argv[i++]);
    tmp->addr = tmp->addr & tmp->mask;
    tmp->next = NULL;
  }

  tmp = list;
  list = list->next;
  free(tmp);

  arp(list, argv[1]);
  
  return 0;
}
